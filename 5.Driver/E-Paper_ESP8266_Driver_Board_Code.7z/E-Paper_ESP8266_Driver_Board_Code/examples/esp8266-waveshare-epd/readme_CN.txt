/*****************************************************************************
* | File      	:   Readme_CN.txt
* | Author      :   Waveshare team
* | Function    :   Help with use
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2020-02-25
* | Info        :   在这里提供一个中文版本的使用文档，以便你的快速使用
******************************************************************************/
这个文件是帮助您使用本例程。

1.基本信息：
本例程是基于Arduino进行开发的，例程均在E-Paper ESP8266 Driver Board上进行了验证;

2.基本使用：
    方法1：将整个esp8266-waveshare-epd文件夹复制到C:\Users\user\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\2.6.3\libraries
    然后打开Arduino IDE,在文件=》示例=》找到对应的demo，下载到E-Paper ESP8266 Driver Board即可。

	方法2：将src文件夹放到 “文档”\Arduino\libraries 下，然后直接打开examples文件夹内对应的工程即可。
